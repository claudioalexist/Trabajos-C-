﻿/*Programa que puede simular un animal como mascota, en este caso sera un conejo. Se le puede alimentar, dormir, jugar con el, bañarlo,
 * y curarlo de alguna herida o enfermedad. 
 * Nota: Puede morir cuando no se le da de comer o no se cura una enfermedad, o bien terminando el programa matandolo usted mismo presionando F1
 * cuando se solicita satisfacer una necesitad de la mascota!!
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pinguino
{
    class Program
    {
        const string TITLE_CONSOLE = "Mi Tamagotchi!";
        const int CONSOLE_HEIGHT = 60;
        const int CONSOLE_WIDHT = 150;        
        const int DELAY = 2000;
        static void Main(string[] args)
        {
            //Ojo, presiono la tecla para satisfacer la necesidad solo cuando se lo pida. No presione de mas porfavor
            Console.Title = TITLE_CONSOLE;
            Console.WindowHeight = CONSOLE_HEIGHT;
            Console.WindowWidth = CONSOLE_WIDHT;
            Console.BackgroundColor = ConsoleColor.DarkGreen;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();            
            Console.WriteLine("Listo para crear su mascota!!!\nIngrese el nombre para el conejo:");
            string nombre = Console.ReadLine();
            Mascota myMascota = new Mascota(nombre);
            myMascota.mascotaActuando();
            System.Threading.Thread.Sleep(DELAY);
            Console.ReadKey();
        }
    }
}