﻿//Recuerde que puede matar a su mascota presionando F1 cuando se solicite atender una necesidad
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
namespace pinguino
{
    class Mascota
    {
        private string nombre;
        private int edad = 0;
        private int contadorSalud = 5;
        private int contadorAlimentacion = 5;
        private bool hambriento;
        private bool sucio;
        private bool aburrido;
        private bool enfermo;
        private bool cansado;
        private bool muerto;

        private Random random = new Random();
        int numeroAleatoro = 0;
        private Timer timer1;
        private Timer timer2;
        const int DELAY_ACTIVITY = 5000;  //Constante para el tiempo de espera para que la mascota realize una accion.
        const int DELAY_AGE = 60000;       //Constante para el tiempo de espera para el aumento de edad de la mascota.
        private Figura figura = new Figura();
        private ConsoleKeyInfo selectkey;

        //Enumeracion para varios usos
        enum Etapa { BEBE, NIÑO, JOVEN, ADULTO, VIEJO };
        enum Menu { COMIDA1, COMIDA2, COMIDA3 };
        private Etapa etapaMascota;
        private Menu comida;

        //---------------------------------------------Constructor--------------------------------------------
        public Mascota(string nombre)
        {
            this.timer1 = new Timer();
            this.timer2 = new Timer();
            this.nombre = nombre;
            this.edad = 0;
            this.hambriento = false;
            this.sucio = false;
            this.aburrido = false;
            this.enfermo = false;
            this.cansado = false;
            this.muerto = false;
            //La mascota se va a presentar cuando recien nace!!
            presentarse();

            //Manejo de los timepos, uno para el tiempo de cada accion y otro para controlar la edad
            this.timer1.Elapsed += new ElapsedEventHandler(seleccionarActividad);
            this.timer1.Interval = DELAY_ACTIVITY;
            this.timer1.Enabled = true;
            this.timer2.Elapsed += new ElapsedEventHandler(crecer);
            this.timer2.Interval = DELAY_AGE;
            this.timer2.Enabled = true;
        }    
        #region Propiedades Set y Get
        public bool Hambriento
        {
            get
            {
                return this.hambriento;
            }
            set
            {
                this.hambriento = value;
            }
        }
        public bool Sucio
        {
            get
            {
                return this.sucio;
            }
            set
            {
                this.sucio = value;
            }
        }
        public bool Aburrido
        {
            get
            {
                return this.aburrido;
            }
            set
            {
                this.aburrido = value;
            }
        }
        public bool Enfermo
        {
            get
            {
                return this.enfermo;
            }
            set
            {
                this.enfermo = value;
            }
        }
        public bool Cansado
        {
            get
            {
                return this.cansado;
            }
            set
            {
                this.cansado = value;
            }
        }

        public bool Muerto
        {
            get
            {
                return this.muerto;
            }
            set
            {
                this.muerto = value;
            }
        }
        #endregion

        #region Acciones de la Mascota
        public void presentarse()
        {
            figura.saludarAlNacer();
            System.Threading.Thread.Sleep(500);
            Console.SetCursorPosition(40,10); Console.WriteLine("\t\t\tHOLA, HOLA, HOLA MUNDO!!!");                                     
            System.Threading.Thread.Sleep(DELAY_ACTIVITY);
            Console.SetCursorPosition(40,25);Console.WriteLine("SOY: " + this.nombre);
            Console.SetCursorPosition(40, 26); Console.Write("Continuar...");
            Console.ReadKey();
            Console.Clear();
            Console.CursorVisible = false;
        }
        //Procedimiento comer, si su alimentacion llega a 0 la mascota morira.
        public void comer()
        {
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.Clear();

            presentarEstadisticas();
            Random comidaAlAzar = new Random();
            switch (comidaAlAzar.Next(1,4))     //Seleccion de una comida especial al azar
            {
                case 1: 
                    comida = Menu.COMIDA1;
                    Console.WriteLine("Quiero comer Dulces y Gaseosa!!!");
                break;
                case 2: 
                    comida = Menu.COMIDA2;
                    Console.WriteLine("Quiero comer Pie y Fresco!!!");
                break;
                case 3: 
                    comida = Menu.COMIDA3;
                    Console.WriteLine("Quiero comer Hamburgesa y Limonada!!!");
                break;                
            }

            Console.WriteLine("Presione 1 para alimentar u otra para ignorar!");
            Console.CursorVisible = true;
            selectkey = Console.ReadKey();
            Console.CursorVisible = false;
            if((selectkey.Key == ConsoleKey.D1) || (selectkey.Key == ConsoleKey.NumPad1))
            {
                this.hambriento = false;
                figura.conejoComer();
                Console.WriteLine("\nYa estoy lleno!!!");
                contadorAlimentacion++;
                presentarEstadisticas();
            }
            else if(selectkey.Key == ConsoleKey.F1)
            {
                this.muerto = true;                
            }
            else
            {
                contadorAlimentacion--;
                if(contadorAlimentacion <= 0)
                {
                    this.muerto = true;
                }                               
                figura.enojar();
                presentarEstadisticas();                
            }

            System.Threading.Thread.Sleep(DELAY_ACTIVITY);
        }

        public void bañar()
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Clear();
            presentarEstadisticas();
            Console.WriteLine("Estoy Sucio!!!");
            System.Threading.Thread.Sleep(1000);
            figura.conejoLimpiar();
            
            Console.WriteLine("Presione 1 para limpiar u otra tecla para ignorar!");
            Console.CursorVisible = true;
            selectkey = Console.ReadKey();
            Console.CursorVisible = false;
            if ((selectkey.Key == ConsoleKey.D1) || (selectkey.Key == ConsoleKey.NumPad1))
            {
                this.sucio = false;
                Console.Clear();
                figura.estarQuieto();
                Console.WriteLine("Estoy Limpio!!!");                
            }
            else if(selectkey.Key == ConsoleKey.F1)
            {
                this.muerto = true;                
            }
            else
            {
                figura.enojar();                
            }
            presentarEstadisticas();
            System.Threading.Thread.Sleep(DELAY_ACTIVITY);
        }

        public void jugar()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;            
            Console.Clear();
            presentarEstadisticas();
            Console.WriteLine("Quiero jugar pelota!!!");
            figura.estarQuieto();

            Console.WriteLine("Presione 1 para jugar u otra tecla para ignorar!");
            Console.CursorVisible = true;
            selectkey = Console.ReadKey();
            Console.CursorVisible = false;
            if ((selectkey.Key == ConsoleKey.D1) || (selectkey.Key == ConsoleKey.NumPad1))
            {
                this.aburrido = false;
                figura.conejoJugar();
                figura.estarQuieto();
                Console.WriteLine("\nYa juge, gracias xD");
            }
            else if(selectkey.Key == ConsoleKey.F1)
            {
                this.muerto = true;                
            }
            else
            {
                figura.enojar();
            }
            presentarEstadisticas();
            System.Threading.Thread.Sleep(DELAY_ACTIVITY);
        }
        
        public void dormir()
        {
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            presentarEstadisticas();
            Console.WriteLine("Quiero dormir!!!");            

            Console.WriteLine("Presione 1 para atender u otra tecla para ignorar!");
            Console.CursorVisible = true;
            selectkey = Console.ReadKey();
            Console.CursorVisible = false;
            if ((selectkey.Key == ConsoleKey.D1) || (selectkey.Key == ConsoleKey.NumPad1))
            {
                this.cansado = false;
                figura.conejoDormir();
            }
            else if(selectkey.Key == ConsoleKey.F1)
            {
                this.muerto = true;                
            }
            else
            {
                figura.enojar();                
            }
            presentarEstadisticas();
            System.Threading.Thread.Sleep(DELAY_ACTIVITY);
        }

        //Metodo para curar, si su salud llega a 0 la mascota morira.
        public void curar()
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Clear();
            presentarEstadisticas();
            Console.WriteLine("Estoy enfermo!!!");
            System.Threading.Thread.Sleep(1000);
            figura.conejoEnfermar();

            Console.WriteLine("Presione 1 para sanar u otra tecla para ignorar!");
            Console.CursorVisible = true;
            selectkey = Console.ReadKey();
            Console.CursorVisible = false;
            if ((selectkey.Key == ConsoleKey.D1) || (selectkey.Key == ConsoleKey.NumPad1))
            {
                this.enfermo = false;
                Console.Clear();
                figura.estarQuieto();
                Console.WriteLine("\nCurado estoy!!!");
                contadorSalud++;
                presentarEstadisticas();
            }
            else if(selectkey.Key == ConsoleKey.F1)
            {
                this.muerto = true;                
            }
            else
            {
                contadorSalud--;
                if (contadorSalud <= 0) { 
                    this.muerto = true;
                }                               
                figura.enojar();
                presentarEstadisticas();                
            }
            System.Threading.Thread.Sleep(DELAY_ACTIVITY);
        }        
        #endregion

        public void mascotaActuando()
        {
            figura.estarQuieto();
            do
            {                
                switch (numeroAleatoro)     //Seleccion al azar de una accion que la mascota desea hacer
                {
                    case 1:
                        this.aburrido = true;
                        jugar();
                        break;
                    case 2:
                        this.cansado = true;
                        dormir();
                        break;
                    case 3:
                        this.sucio= true;
                        bañar();
                    break;
                    case 4:
                        this.hambriento = true;
                        comer();
                    break;
                    case 5:
                        this.enfermo = true;
                        curar();
                    break;
                }                
            } while (this.muerto == false);
            figura.conejoMuerto();
            Console.CursorVisible = true;
            Console.WriteLine("\n{0} esta Muerto!!!",this.nombre.ToUpper());            
        }

        public void seleccionarActividad(object Source, ElapsedEventArgs e)
        {            
            numeroAleatoro = random.Next(1, 6);
        }

        public void crecer(object Source, ElapsedEventArgs e)
        {
            this.edad += 5;            
            if(this.edad <= 10)
            {
                etapaMascota = Etapa.NIÑO;                               
            }
            else if((this.edad > 10) && (this.edad <= 25))
            {
                etapaMascota = Etapa.JOVEN;                
            }
            else if((this.edad >= 30) && (this.edad <= 45))
            {
                etapaMascota = Etapa.ADULTO;                
            }
            else if(this.edad >=50)
            {
                etapaMascota = Etapa.VIEJO;                               
            }
        }

        public void presentarEstadisticas()
        {
            Console.SetCursorPosition(100, 0); Console.WriteLine(this.nombre.ToUpper());
            Console.SetCursorPosition(100, 1); Console.WriteLine("|  Edad: {0} ",this.edad);
            Console.SetCursorPosition(100, 2); Console.WriteLine("|  Hambriento: {0}", this.hambriento);
            Console.SetCursorPosition(100, 3); Console.WriteLine("|  Enfermo: {0}", this.enfermo);
            Console.SetCursorPosition(100, 4); Console.WriteLine("|  Etapa: {0}", this.etapaMascota);
            Console.SetCursorPosition(100, 5); Console.WriteLine("|  Salud: {0}", this.contadorSalud);
            Console.SetCursorPosition(100, 6); Console.WriteLine("|  Alimentacion: {0}", this.contadorAlimentacion);
            Console.SetCursorPosition(100, 7); Console.WriteLine("|________________________________");
        }
    }
}